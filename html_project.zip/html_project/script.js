function fun() {
    var a = document.getElementById("name").value;
    var b = document.getElementById("number").value;
    var c = document.getElementById("email").value;
    var d = document.getElementById("message").value;

    var atposition = c.indexOf("@");
    var dotposition = c.lastIndexOf(".");
    if (a == null || a == "") {
        alert("Name can't be empty")
    }
    if (b.length < 10 || b.length > 10) {
        alert("Please enter a valid phone number")
    }

    if (isNaN(b)) {
        alert("Please anter a valid phone number")
    }



    if (atposition < 1 || dotposition < atposition + 2 || dotposition + 2 >= x.length) {
        alert("Please enter a valid e-mail address");
    }
    if (atposition == null && dotposition == null) {
        alert("Please enter a valid e-mail address");
    }
    if (c == null) {
        alert("Please enter a valid e-mail address");
    }

    if (d == null || d == "") {
        alert("message can't be empty")
    }

}